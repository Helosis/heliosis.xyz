=======================================================
IPTV M3U PLAYLIST & BUKET EDITÖRÜ (PORTABLE / KURULUMSUZ)
=======================================================

Bu uygulama Windows ortamında hiçbir harici kütüphane veya
kurulum (setup) gerektirmeden çalışır.

NASIL ÇALIŞTIRILIR?
-------------------
• Klasördeki "M3U_Editor.bat" dosyasına çift tıklayarak anında başlatabilirsiniz.

YENİ VE GELİŞMİŞ ÖZELLİKLER:
---------------------------

1. KUTUCUKLAR (CHECKBOX) VE TOPLU SİLME:
   • Kanallar Tablosu:
     - Her kanalın en solundaki "[✓]" sütunundaki kutucuğa tıklayarak veya
       kanalı seçip KLAVYEDEN BOŞLUK (Space) tuşuna basarak işaretleyebilirsiniz (☑ / ☐).
     - Üstteki "☑ Tümünü Seç" veya "[✓]" başlığına tıklayarak tüm kanalları işaretleyebilirsiniz.
     - "🗑️ İşaretlileri Sil" butonuna basarak kutucuğu işaretli kanalların hepsini tek hamlede silebilirsiniz.
   • Buketler (Sol Panel):
     - Buketlerin solundaki kutucuklara tıklayarak birden fazla buketi işaretleyebilirsiniz.
     - "🗑️ İşaretli Buketleri Sil" butonuyla istemediğiniz tüm buketleri ve içlerindeki kanalları anında silebilirsiniz.

2. TUT & SÜRÜKLE (DRAG & DROP) DÜZENLEME:
   • Kanal Sıralaması Değiştirme:
     - Herhangi bir kanalı fareyle tutup listenin yukarısına veya aşağısına sürükleyip bıraktığınızda
       kanal doğrudan bıraktığınız sıraya yerleşir.
   • Buketler Arası Taşıma:
     - Bir veya birden fazla kanalı fareyle tutup sol taraftaki buket listesinde istediğiniz bir bukete
       (örneğin "⭐ Favoriler" veya "Spor" buketine) sürükleyip bırakabilirsiniz!

3. ⭐ FAVORİLER BUKETİ:
   • Sol panelin en üstünde kalıcı "⭐ Favoriler" buketi bulunur.
   • İstediğiniz kanalları seçip üstteki "⭐ Favorilere Ekle" butonuna basabilir,
     sağ tık yapıp "⭐ Favorilere Ekle" diyebilir veya doğrudan sürükleyip içine atabilirsiniz.

4. DİĞER ÖZELLİKLER:
   • ⚡ Yayınları Test Et: Linklerin aktifliğini kontrol eder (Çalışanlar yeşil, ölüler kırmızı).
   • 🔍 Anlık Arama: Binlerce kanal arasından filtreleme yapar.
   • Çift Tıklama: Kanal adını, linkini, logosunu veya TVG ID'sini düzenleme penceresini açar.
